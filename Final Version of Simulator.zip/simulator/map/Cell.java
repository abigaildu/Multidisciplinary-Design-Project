package map;

import config.MapConfig;
import map.mapElements.SimulatorObstacle;

public class Cell {
    
    private final int row;
    private final int col;

    private boolean wayPoint;
    private boolean explored;

    private boolean virtualWall;

    private SimulatorObstacle obstacle;
    private boolean hasObstacle;

    private boolean isFastestPath;


    private int x;
    private int y;
    private int size;

    public Cell(int row, int col) {
        
        this.row = row;
        this.col = col;

        this.explored = false;
        this.hasObstacle = false;
        this.virtualWall = false;
        this.wayPoint = false;

        x = row * MapConfig.CELL_SIZE + MapConfig.CELL_PADDING + MapConfig.X_OFFSET;
		y = MapConfig.MAP_HEIGHT - (col * MapConfig.CELL_SIZE - MapConfig.CELL_PADDING);
		size = MapConfig.CELL_SIZE - (MapConfig.CELL_PADDING * 2);
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public int[] getCoords() {
        return new int[] {row, col};
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSize() {
        return size;
    }

    public void setExplored(boolean explored) {
        this.explored = explored;
    }

    public boolean hasBeenExplored() {
        return explored;
    }

    public void setWayPoint(boolean wayPoint) {
        this.wayPoint = wayPoint;
    }

    public boolean isWayPoint() {
        return wayPoint;
    }

    public void setVirtualWall(boolean virtualWall) {
        this.virtualWall = virtualWall;
    }

    public boolean isVirtualWall() {
        return virtualWall;
    }

    public boolean hasObstacle() {
        return hasObstacle;
    }

    public void placeObstacle(SimulatorObstacle obstacle) {
        this.obstacle = obstacle;
        hasObstacle = true;
    }

    public SimulatorObstacle getObstacle() {
        return obstacle;
    }

    public void removeObstacle() {
        obstacle = null;
        hasObstacle = false;
    }

    public void setFastestPath(boolean fastestPath) {
        this.isFastestPath = fastestPath;
    }

    public boolean isFastestPath() {
        return isFastestPath;
    }

    @Override
    public String toString() {
        return "{" + row + ", " + col + "}";
    }
}
