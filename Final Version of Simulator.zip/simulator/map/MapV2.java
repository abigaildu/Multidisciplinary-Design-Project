package map;

import config.MapConfig;
import config.RobotConfig.Direction;
import map.mapElements.SimulatorObstacle;
import pathFinding.AstarV2;
import pathFinding.Dubin;
import robot.Robot;
import robot.RobotV2;

import java.util.List;
import javax.swing.Timer;

import javax.swing.JPanel;

import commands.Command;
import commands.StraightCommand;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class MapV2 extends JPanel {

    // the arena is a 2D array of Cells
    private Cell[][] arena;

    private RobotV2 robot = new RobotV2(new int[] { 1, 0 });

    private List<SimulatorObstacle> obstacles;
    private List<Cell> obstacleCells;

    public boolean addObstacle = true;

    public List<Position> path;

    int pathIndex = 0;

    Timer timer;

    public MapV2() {

        robot.setDir(Direction.NORTH);

        int width = MapConfig.NUM_COLS * MapConfig.CELL_SIZE;
        int height = MapConfig.NUM_ROWS * MapConfig.CELL_SIZE;

        setPreferredSize(new Dimension(width, height));

        arena = new Cell[MapConfig.NUM_ROWS][MapConfig.NUM_COLS];

        for (int row = 0; row < MapConfig.NUM_ROWS; row++) {
            for (int col = 0; col < MapConfig.NUM_COLS; col++) {

                arena[row][col] = new Cell(row, col);

                var curCell = arena[row][col];

                // we also want to set up virtual walls on the boundaries of the arena
                // so that our robot will not overstep;
                if (isBoundary(row, col))
                    curCell.setVirtualWall(true);

                if (inStartZone(row, col))
                    curCell.setExplored(true);
            }
        }

        obstacles = new ArrayList<>();
        obstacleCells = new ArrayList<>();

        this.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
                handleMouseClick(e);
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }

        });
    }

    public Cell[][] getArena() {
        return arena;
    }

    public void addRobot(RobotV2 robot) {

        this.robot = robot;
    }

    public RobotV2 getRobot() {
        return robot;
    }

    public boolean isBoundary(int row, int col) {

        if (row == 0 || col == 0 ||
                row == MapConfig.NUM_ROWS - 1 || col == MapConfig.NUM_COLS - 1)
            return true;

        return false;
    }

    public boolean isBoundaryRow(int row) {
        return row == 0 || row >= MapConfig.NUM_ROWS - 1;
    }

    public boolean isBoundaryCol(int col) {
        return col == 0 || col >= MapConfig.NUM_COLS - 1;
    }

    public Cell getStartCell() {

        return arena[MapConfig.START_ROW][MapConfig.START_COL];
    }

    public boolean inStartZone(int row, int col) {

        if (row >= MapConfig.START_ROW - 1 && row <= MapConfig.START_ROW + 1 &&
                col >= MapConfig.START_COL - 1 && col <= MapConfig.START_COL + 1)
            return true;

        return false;
    }

    public Cell getEndCell() {

        return arena[MapConfig.GOAL_ROW][MapConfig.GOAL_COL];
    }

    public boolean inEndZone(int row, int col) {

        if (row >= MapConfig.GOAL_ROW - 1 && row <= MapConfig.GOAL_ROW + 1 &&
                col >= MapConfig.GOAL_COL - 1 && col <= MapConfig.GOAL_COL + 1)
            return true;

        return false;
    }

    // maybe useful
    public boolean areValidRobotCoordinates(int row, int col) {

        var robotOffsets = robot.getOccupyingCoordsOffset();

        boolean validCoords = true;

        for (var offset : robotOffsets) {
            var x = offset[0] + row;
            var y = offset[1] + col;

            validCoords = areValidCoordinates(x, y) && !arena[x][y].hasObstacle();

            if (!validCoords)
                return false;
        }

        return areValidCoordinates(row, col) && validCoords;
    }

    public boolean areValidCoordinates(int row, int col) {

        if (row < 0 || col < 0 ||
                row >= MapConfig.NUM_ROWS || col >= MapConfig.NUM_COLS)
            return false;

        return true;
    }

    public List<SimulatorObstacle> getObstacles() {
        return obstacles;
    }

    public List<Cell> getObstacleCells() {
        return obstacleCells;
    }

    public void removeObstacle(int x, int y) {

        for (int i = 0; i < obstacleCells.size(); i++) {
            var cell = obstacleCells.get(i);
            var obs = obstacles.get(i);

            if (obs.getX() == x && obs.getY() == y) {
                obstacleCells.remove(i);
                obstacles.remove(i);
            }
        }

        arena[x][y].removeObstacle();

        // now we have to remove all the walls around the obstacle;
        // virtual walls above and below the object;
        for (int r = x - 1; r <= x + 1; r++) {

            if (areValidCoordinates(r, y + 1))
                arena[r][y + 1].setVirtualWall(false);

            if (areValidCoordinates(r, y - 1))
                arena[r][y - 1].setVirtualWall(false);

        }

        // virtual walls to the right and left of the object
        for (int c = y - 1; c <= y + 1; c++) {

            if (areValidCoordinates(x + 1, c))
                arena[x + 1][c].setVirtualWall(false);

            if (areValidCoordinates(x - 1, c))
                arena[x - 1][c].setVirtualWall(false);
        }

        // we also want to reset all the cells to "not fastest path";
        resetFastestPath();
    }

    public void resetFastestPath() {
        for (var row : arena) {
            for (var cell : row) {
                cell.setFastestPath(false);
            }
        }
    }

    public void placeObstacle(SimulatorObstacle obstacle, int row, int col) {

        // obstacles cannot be places in the start zone or end zone;
        if (inStartZone(row, col))
            return;

        // now we place the obstacle at the desired coords;
        var curCell = arena[row][col];

        // obstacles cannot be placed on a cell that already has another obstacle
        // lets rotate this obstacle instead;
        if (curCell.hasObstacle()) {
            return;
        }

        // now we place the obstacle
        curCell.placeObstacle(obstacle);
        obstacles.add(obstacle);
        obstacleCells.add(arena[row][col]);

        // now we need to add virtual walls on around the obstacle;

        // virtual walls above and below the object;
        for (int r = row - 1; r <= row + 1; r++) {

            if (areValidCoordinates(r, col + 1))
                arena[r][col + 1].setVirtualWall(true);

            if (areValidCoordinates(r, col - 1))
                arena[r][col - 1].setVirtualWall(true);

        }

        // virtual walls to the right and left of the object
        for (int c = col - 1; c <= col + 1; c++) {

            if (areValidCoordinates(row + 1, c))
                arena[row + 1][c].setVirtualWall(true);

            if (areValidCoordinates(row - 1, c))
                arena[row - 1][c].setVirtualWall(true);
        }

        resetFastestPath();
    }

    public void rotateObstacle(int x, int y) {
        SimulatorObstacle curObstacle = arena[x][y].getObstacle();
        Direction obsDir = curObstacle.getDirection();
        curObstacle.setDirection(Direction.getNextClk(obsDir));

        resetFastestPath();
    }

    public int calcAreaExplored() {

        int area = 0;

        for (var row : arena) {
            for (var cell : row) {

                if (cell.hasBeenExplored())
                    area++;
            }
        }

        return area;
    }

    public Position getStartPosition() {

        Cell start = getStartCell();
        // return new Position(start.getRow(), start.getCol(),
        // MapConfig.ROBOT_START_DIR);
        // previously, we were getting the position of the center of the robot
        // return robot.getPosition();
        return new Position(1, 0, Direction.NORTH);
    }

    public Position getEndPosition() {

        Cell end = getEndCell();
        return new Position(end.getRow(), end.getCol(), MapConfig.ROBOT_END_DIR);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the colored grid
        for (int i = 0; i < MapConfig.NUM_ROWS; i++) {
            for (int j = 0; j < MapConfig.NUM_COLS; j++) {

                int x = getXCoord(i);
                int y = getYCoord(j);

                Cell cell = arena[x][y];
                // System.out.println(x + " " + y);

                Color cellColor = MapConfig.COLOR_NONE;
                if (inStartZone(x, y))
                    cellColor = MapConfig.COLOR_START;
                // else if (inEndZone(x, y)) cellColor = MapConfig.COLOR_GOAL;
                else if (cell.isFastestPath())
                    cellColor = MapConfig.COLOR_FP;
                else if (cell.isVirtualWall())
                    cellColor = Color.RED;
                else if (!cell.hasBeenExplored())
                    cellColor = MapConfig.COLOR_UNEXPLORED;
                else if (cell.isWayPoint())
                    cellColor = MapConfig.COLOR_WAYPOINT;

                g.setColor(cellColor);

                g.fillRect(i * MapConfig.CELL_SIZE, j * MapConfig.CELL_SIZE, MapConfig.CELL_SIZE, MapConfig.CELL_SIZE);
            }
        }

        g.setColor(Color.BLACK); // Line color
        for (int i = 0; i <= MapConfig.NUM_ROWS; i++) {
            g.drawLine(i * MapConfig.CELL_SIZE, 0, i * MapConfig.CELL_SIZE, MapConfig.NUM_COLS * MapConfig.CELL_SIZE); // Vertical
                                                                                                                       // lines
            g.drawLine(0, i * MapConfig.CELL_SIZE, MapConfig.NUM_ROWS * MapConfig.CELL_SIZE, i * MapConfig.CELL_SIZE); // Horizontal
                                                                                                                       // lines
        }

        // Now we draw our obstacles
        for (SimulatorObstacle obstacle : obstacles) {
            obstacle.drawObstacle(g);
        }

        // now lets draw our robot
        robot.drawRobot(g);

        g.setFont(new Font("Arial", Font.PLAIN, 14));

        for (int x = 0; x < MapConfig.NUM_ROWS; x++) {
            g.drawString(String.valueOf(x), x * MapConfig.CELL_SIZE + MapConfig.CELL_SIZE / 2 - 10,
                    MapConfig.NUM_ROWS * MapConfig.CELL_SIZE + 20); // Adjusted position for visibility
        }

        // Label the y-axis (left of the grid)
        for (int y = 0; y < MapConfig.NUM_ROWS; y++) {
            g.drawString(String.valueOf(MapConfig.NUM_ROWS - 1 - y), 5,
                    y * MapConfig.CELL_SIZE + MapConfig.CELL_SIZE / 2); // Shift left for
            // y-axis labels
        }

        printArena();
    }

    public void printArena() {

        // print arena to console.
        for (var row : arena) {
            for (var cell : row) {

                String marker = ".";

                if (cell.hasObstacle())
                    marker = "O";
                if (cell.isVirtualWall())
                    marker = "W";

                System.out.print(marker + " ");
            }

            System.out.println();
        }
    }

    private void handleMouseClick(MouseEvent e) {
        int clickedX = e.getX() / MapConfig.CELL_SIZE; // Convert pixel coordinates to grid coordinates
        int clickedY = e.getY() / MapConfig.CELL_SIZE;

        // coords for the map;
        int x = getXCoord(clickedX);
        int y = getYCoord(clickedY);

        // System.out.println(x + " " + y);

        if (!addObstacle) {
            removeObstacle(x, y);
            repaint();
            return;
        }

        if (arena[x][y].hasObstacle()) {
            rotateObstacle(x, y);
            repaint();
        }

        else {
            SimulatorObstacle newObs = new SimulatorObstacle(Direction.NORTH, x, y);
            placeObstacle(newObs, x, y);
            repaint();
        }

    }

    public static int getXCoord(int x) {
        return x;
    }

    public static int getYCoord(int y) {
        return MapConfig.NUM_COLS - 1 - y;
    }

    public List<Command> getCommands() {

        AstarV2 astar = new AstarV2(this, robot);
        path = astar.run();

        return Command.compressCommands(Command.convertToCommand(path));
    }

    public void findPath() {

        AstarV2 astar = new AstarV2(this, robot);
        path = astar.run();

        // for(var position : path) {

        // int x = position.getIntX();
        // int y = position.getIntY();

        // arena[x][y].setFastestPath(true);
        // }

        for (int i = 0; i < path.size() - 1; i++) {

            Position curPos = path.get(i);
            Position nextPos = path.get(i + 1);

            int dx = nextPos.getIntX() - curPos.getIntX();
            int dy = nextPos.getIntY() - curPos.getIntY();

            int x1 = curPos.getIntX();
            int y1 = curPos.getIntY();

            int x2 = nextPos.getIntX();
            int y2 = nextPos.getIntY();

            arena[x1][y1].setFastestPath(true);

            // we only need to interpolate the points
            // if the angles change between positions;
            if (curPos.getDir() != nextPos.getDir()) {

                int tempx = x1;
                int tempy = y1;

                switch (curPos.getDir()) {
                    case NORTH:
                    case SOUTH:

                        if (dy > 0)
                            for (tempy = y1; tempy < y2; tempy++)
                                arena[x1][tempy].setFastestPath(true);

                        if (dy < 0)
                            for (tempy = y1; tempy > y2; tempy--)
                                arena[x1][tempy].setFastestPath(true);

                        if (dx > 0)
                            for (tempx = x1; tempx < x2; tempx++)
                                arena[tempx][tempy].setFastestPath(true);

                        else
                            for (tempx = x1; tempx > x2; tempx--)
                                arena[tempx][tempy].setFastestPath(true);
                        break;

                    // after the x coords, we need to do the same with the y coords;

                    case EAST:
                    case WEST:

                        if (dx > 0)
                            for (tempx = x1; tempx < x2; tempx++)
                                arena[tempx][y1].setFastestPath(true);

                        else
                            for (tempx = x1; tempx > x2; tempx--)
                                arena[tempx][y1].setFastestPath(true);

                        if (dy > 0)
                            for (tempy = y1; tempy < y2; tempy++)
                                arena[tempx][tempy].setFastestPath(true);

                        if (dy < 0)
                            for (tempy = y1; tempy > y2; tempy--)
                                arena[tempx][tempy].setFastestPath(true);

                    default:
                        break;
                }
            }
        }

        repaint();
        System.out.println(Command.convertToCommand(path) + "\n");
        System.out.println("-".repeat(150));
        System.out.println(Command.compressCommands(Command.convertToCommand(path)));
    }

    public void reset() {

        for (int i = 0; i < MapConfig.NUM_ROWS; i++) {
            for (int j = 0; j < MapConfig.NUM_COLS; j++) {
                Cell curCell = arena[i][j];

                curCell.removeObstacle();
                curCell.setFastestPath(false);
                curCell.setVirtualWall(false);

                if (isBoundary(i, j))
                    curCell.setVirtualWall(true);
            }
        }

        obstacles.clear();
        obstacleCells.clear();

        addObstacle = true;

        robot.setCoords(new int[] { 1, 0 });
        robot.setDir(MapConfig.ROBOT_START_DIR);
        repaint();
    }

    public void animateRobot() {

        pathIndex = 0;

        timer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (pathIndex == path.size() - 1)
                    timer.stop();

                Position curPos = path.get(pathIndex);
                robot.setCoords(
                        new int[] {
                                curPos.getIntX(),
                                curPos.getIntY()
                        });

                robot.setDir(curPos.getDir());
                repaint();
                pathIndex++;
            }
        });

        timer.start();
    }
}
