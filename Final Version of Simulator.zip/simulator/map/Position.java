package map;

import config.RobotConfig;
import config.RobotConfig.Direction;


public class Position {
    
    private double x;
    private double y;
    private RobotConfig.Direction dir;
    private double angularPos;

    public Position(double row, double col, RobotConfig.Direction dir) {
        
        this(row, col, Direction.getAngle(dir));
        this.dir = dir;
    }

    public Position(double x, double y, double angularPos) {
        this(x, y);
        this.angularPos = angularPos;
    }

    public Position(double x, double y) {

        this.x = x;
        this.y = y;
    }

    public void setDir(Direction dir) {
        this.dir = dir;
        angularPos = Direction.getAngle(dir);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public int getIntX() {
        // return (int) x;
        return (int) Math.round(x);
    }

    public int getIntY() {
        // return (int) y;
        return (int) Math.round(y);
    }

    public void setAngle(double angle) {
        this.angularPos = angle;
    }

    public double getAngle() {
        return angularPos;
    }

    public RobotConfig.Direction getDir() {
        return dir;
    }

    public String getEqualString() {
        return "" + x + y + dir;
    }

    @Override
    public String toString() {
        return String.format("{ %.2f, %.2f, %.2f }", x, y, angularPos);
    }

    @Override
    public boolean equals(Object o) {

        if(o instanceof Position pos) {

            return pos.x == x && pos.y == y && angularPos == pos.angularPos;
        }

        return false;
    }
}
