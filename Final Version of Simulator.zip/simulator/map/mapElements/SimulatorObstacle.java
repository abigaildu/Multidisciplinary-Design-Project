package map.mapElements;

import config.MapConfig;
import config.RobotConfig;
import config.SimulatorConfig;
import config.RobotConfig.Direction;
import map.Position;
import map.SimulatorMap;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;


public class SimulatorObstacle {

    private RobotConfig.Direction facing;
    private int x;
    private int y;

    private Image image = SimulatorConfig.OBSTACLE_IMAGE;

    public SimulatorObstacle(RobotConfig.Direction facing, int x, int y) {
        
        this.facing = facing;
        this.x = x;
        this.y = y;
    }

    public RobotConfig.Direction getDirection() {
        return facing;
    }

    public void setDirection(RobotConfig.Direction facing) {
        this.facing = facing;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int[] getCoords() {
        return new int[] {x, y};
    }

    public Position gePosition() {
        return new Position(x, y, facing);
    }

    public void drawObstacle(Graphics g) {
        // Draw the obstacle image at the correct grid location
        int nx = SimulatorMap.getXCoord(x) * MapConfig.CELL_SIZE;
        int ny = SimulatorMap.getYCoord(y) * MapConfig.CELL_SIZE;

        int cx = nx + MapConfig.CELL_SIZE / 2;
        int cy = ny + MapConfig.CELL_SIZE / 2;

        Graphics2D g2d = (Graphics2D) g;
        
        AffineTransform originalTransform = g2d.getTransform();
        double rotation = -Direction.getAngle(facing);
        g2d.rotate(rotation,cx,cy);

        g2d.drawImage(image, nx, ny, MapConfig.CELL_SIZE, MapConfig.CELL_SIZE, null);

        g2d.setTransform(originalTransform);
    }

    @Override
    public String toString() {
        return "Obstacle: " + facing + " " + x + " " + y;
    }
}
