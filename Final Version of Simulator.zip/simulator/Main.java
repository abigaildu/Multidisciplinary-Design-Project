import communication.SocketClient;
import communication.SocketClientV2;

public class Main {

    public static void main(String[] args) {

        SocketClient s = new SocketClient();
        // SocketClientV2 s = new SocketClientV2();
        s.run();
    }
}
