package communication;

import java.util.Arrays;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import commands.Command;
import config.RobotConfig.Direction;
import map.MapV2;
import map.mapElements.SimulatorObstacle;
import robot.RobotV2;

public class SocketClientV2 {

    Scanner sc = new Scanner(System.in);

    public void run() {
        String hostname = "192.168.7.7";
        // this is just a placeholder. we need to replace this with the raspberry pis
        // address

        int port = 6000;

        try (Socket socket = new Socket(hostname, port)) {

            // to send messages;
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, "UTF-8"), true);
            // writer.println("Hello from the algo team");

            // we also need to reveive messages;
            System.out.println("Waiting for Obstacle Coords ...\n");

            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));

            String response = reader.readLine();
            System.out.println(response);

            // the first message i receive is about the placement of the obstacles;
            // ALG:0,18,E,0;18,19,S,1;18,0,W,2;5,0,E,3;10,10,E,4;9,10,W,5;

            MapV2 map = new MapV2();
            RobotV2 robot = new RobotV2(new int[] { 1, 0 });
            map.addRobot(robot);

            // 0,18,E,0;18,19,S,1;18,0,W,2;5,0,E,3;10,10,E,4;9,10,W,5;
            String obstacleCoords = response.substring(4);

            // now we need to convert the coordStrings to actual obstacles;
            String[] coordsArr = obstacleCoords.split(";");
            // ["0,18,E,0", ...];

            for (var coordInfo : coordsArr) {

                // System.out.println(coordInfo);
                // we only need indeces 0,1 and 2;
                // index 3 is just the index of the obstacle in the list;
                var coords = coordInfo.split(",");
                int x = Integer.parseInt(coords[0]);
                int y = Integer.parseInt(coords[1]);
                String d = coords[2];

                SimulatorObstacle newObstacle;

                Direction dir = switch (d) {
                    case "N" -> Direction.NORTH;
                    case "S" -> Direction.SOUTH;
                    case "E" -> Direction.EAST;
                    case "W" -> Direction.WEST;
                    default -> Direction.NORTH;
                };

                newObstacle = new SimulatorObstacle(dir, x, y);

                System.out.println(newObstacle);
                map.placeObstacle(newObstacle, x, y);
                // now we have to add the obstacle to the map;
            }

            // now that we've placed the obstacles
            // we can find the fastest path
            // and send the commands to the RPI;
            List<Command> commands = map.getCommands();

            System.out.print("Command List: ");
            System.out.println(commands);

            writer.println(commands);

            socket.close();
            // response = reader.readLine();
            // System.out.println(response);

            // System.out.println("Enter message: ");
            // String message = sc.nextLine();

            // writer.println(message);
            // writer.flush();
        }

        catch (UnknownHostException e) {
            System.out.println("Server not found " + e.getMessage());
        }

        catch (IOException e) {
            System.out.println("I/O error: " + e.getMessage());
        }

        finally {
            sc.close();
        }
    }
}
