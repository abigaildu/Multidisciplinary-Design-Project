package robot;

import config.MapConfig;
import config.RobotConfig;
import config.RobotConfig.Direction;
import config.SimulatorConfig;
import map.Cell;
import map.Position;
import map.SimulatorMap;
import map.mapElements.SimulatorObstacle;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class SimulatorRobot extends JPanel {

    private int row;
    private int col;
    private Direction dir;
    private double angularPos;

    private int speed;
    private boolean hasReachedGoal;
    private boolean hasReturnedStart;

    private int x;
    private int y;
    private int size;

    private Image image = SimulatorConfig.ROBOT_IMAGE;

    public SimulatorRobot(int[] coords) {

        this.row = coords[0];
        this.col = coords[1];

        this.dir = MapConfig.ROBOT_START_DIR;
        this.speed = RobotConfig.SPEED;
    }

    // getX, getY, getSize and getRotation are all for graphics;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    // public int getSize() {
    // return size;
    // }

    public double getRotation() {

        return switch (dir) {

            case NORTH -> Math.toRadians(90);
            case EAST -> Math.toRadians(0);
            case WEST -> Math.toRadians(180);
            case SOUTH -> Math.toRadians(-90);

        };
    }

    public void setRow(int x) {
        row = x;
    }

    public int getRow() {
        return row;
    }

    public void setCol(int y) {
        col = y;
    }

    public int getCol() {
        return col;
    }

    public void setCoords(int[] newCoords) {
        row = newCoords[0];
        col = newCoords[1];
    }

    public int[] getCoords() {
        return new int[] { row, col };
    }

    public void setDir(RobotConfig.Direction newDir) {
        dir = newDir;
    }

    public RobotConfig.Direction getDir() {
        return dir;
    }

    public void setSpeed(int newSpeed) {
        speed = newSpeed;
    }

    public int getSpeed() {
        return speed;
    }

    public void setHasReachedGoal(boolean hasReacedGoal) {
        this.hasReachedGoal = hasReacedGoal;
    }

    public boolean hasReachGoal() {
        return hasReachedGoal;
    }

    public RobotConfig.Direction updateDir(RobotConfig.Move move) {

        if (move == RobotConfig.Move.TURN_LEFT)
            return RobotConfig.Direction.getNextAntiClk(dir);

        if (move == RobotConfig.Move.TURN_RIGHT)
            return RobotConfig.Direction.getNextClk(dir);

        return dir;
    }

    public Position getPosition() {
        return new Position(row, col, angularPos);
    }

    public Position computeScanningPosition(SimulatorObstacle obstacle) {

        Direction obstacleFacing = obstacle.getDirection();
        var ox = obstacle.getX();
        var oy = obstacle.getY();

        // we need to compute scanning position;
        // we need to get the opposite direction;
        Direction newDir = Direction.getNextClk(Direction.getNextClk(obstacleFacing));

        int x = 0;
        int y = 0;

        switch (obstacleFacing) {
            case NORTH:
                y += 4;
                break;

            case EAST:
                x += 4;
                break;

            case SOUTH:
                y -= 4;
                break;

            case WEST:
                x -= 4;
                break;

            default:
                break;
        }

        return new Position(ox + x, oy + y, newDir);
    }

    public void drawRobot(Graphics g) {

        Graphics2D g2d = (Graphics2D) g;

        // we always need the top left coordinates;
        // this changes depeneding on the robots facing;
        // but, since the robot is always a 3 x 3, we dont need to bother ourselves with
        // the calc;

        int tlx = row - 1;
        int tly = col + 1;

        int width = 3 * MapConfig.CELL_SIZE;
        int height = 3 * MapConfig.CELL_SIZE;

        int nx = SimulatorMap.getXCoord(tlx) * MapConfig.CELL_SIZE;
        int ny = SimulatorMap.getYCoord(tly) * MapConfig.CELL_SIZE;

        int cx = (SimulatorMap.getXCoord(row) * MapConfig.CELL_SIZE) + MapConfig.CELL_SIZE / 2;
        int cy = (SimulatorMap.getYCoord(col) * MapConfig.CELL_SIZE) + MapConfig.CELL_SIZE / 2;

        AffineTransform originalTransform = g2d.getTransform();
        double rotation = -Direction.getAngle(dir);
        g2d.rotate(rotation, cx, cy);

        g2d.drawImage(image, nx, ny, width, height, null);

        g2d.setTransform(originalTransform);

    }

    public int[][] getOccupyingCoordsOffset() {

        return new int[][] {
                { -1, 0 }, { 1, 0 },
                { -1, 1 }, { 1, 1 }, { 0, 1 },
                { -1, -1 }, { 1, -1 }, { 0, -1 }
        };
    }
}
