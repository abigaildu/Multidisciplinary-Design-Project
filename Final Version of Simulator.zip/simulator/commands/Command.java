package commands;

import config.RobotConfig.Direction;
import config.RobotConfig.Move;
import map.Position;
import pathFinding.Dubin;

import java.util.ArrayList;
import java.util.List;

public abstract class Command {

    public abstract String convertToMessage();

    public static Command convertToCommand(Position pos1, Position pos2) {

        var x1 = pos1.getX();
        var y1 = pos1.getY();
        var dir1 = pos1.getDir();

        var x2 = pos2.getX();
        var y2 = pos2.getY();
        var dir2 = pos2.getDir();

        var dx = x2 - x1;
        var dy = y2 - y1;

        // this means its gonna be a straight command
        if (dir1 == dir2) {

            return switch (dir1) {
                case NORTH ->
                    dy > 0 ? new StraightCommand(Move.FORWARD, Math.abs(dy))
                            : new StraightCommand(Move.BACKWARD, Math.abs(dy));

                case SOUTH ->
                    dy < 0 ? new StraightCommand(Move.FORWARD, Math.abs(dy))
                            : new StraightCommand(Move.BACKWARD, Math.abs(dy));

                case EAST ->
                    dx > 0 ? new StraightCommand(Move.FORWARD, Math.abs(dx))
                            : new StraightCommand(Move.BACKWARD, Math.abs(dx));

                case WEST ->
                    dx < 0 ? new StraightCommand(Move.FORWARD, Math.abs(dx))
                            : new StraightCommand(Move.BACKWARD, Math.abs(dx));
            };
        }

        // We've got ourselves a turn
        // directions are always going to be clk or anticlk to each other

        // forward clk --> right turn
        // backward clk --> left turn

        // forward anticlk --> left turn
        // bacward anticlock --> right turn
        else {

            // so first we need to figure out the direction of travel (fwd or bwd);
            Move direction = switch (dir1) {
                case NORTH -> dy > 0 ? Move.FORWARD : Move.BACKWARD;
                case SOUTH -> dy < 0 ? Move.FORWARD : Move.BACKWARD;
                case EAST -> dx > 0 ? Move.FORWARD : Move.BACKWARD;
                case WEST -> dx < 0 ? Move.FORWARD : Move.BACKWARD;
            };

            // now we need to compare dir1 and dir2
            Move turn = switch (direction) {
                case FORWARD -> Direction.isNextClk(dir1, dir2) ? Move.TURN_RIGHT : Move.TURN_LEFT;
                case BACKWARD -> Direction.isNextClk(dir1, dir2) ? Move.TURN_LEFT : Move.TURN_RIGHT;
                default -> Move.TURN_LEFT;
            };

            return new TurnCommand(direction, turn, Dubin.TURN_RADIUS, Math.toDegrees(Dubin.TURN_ANGLE));
        }
    }

    public static List<Command> convertToCommand(List<Position> path) {

        List<Command> commands = new ArrayList<>();

        // we might have to add a check here to see if there is more than 1 point in the
        // path
        // but we'll do this later
        // or maybe we'll never have to

        for (int i = 0; i < path.size() - 1; i++) {

            Position startPos = path.get(i);
            Position nextPos = path.get(i + 1);

            commands.add(convertToCommand(startPos, nextPos));
        }

        return commands;
    }

    // this function optimises the command list;
    // remeber that we need to send a copy of the commands;
    public static List<Command> compressCommands(List<Command> commands) {

        // we need to check if the commands are the same;
        List<Command> compressedCommands = new ArrayList<>();

        int curCommandIndex = 0;
        Command cur = commands.get(curCommandIndex);

        int i = 0;
        for (i = 1; i < commands.size(); i++) {

            Command temp = commands.get(i);
            // if the two commands are the same,
            // all we have to do is add the distances, if they are straight commands.
            // or add the angles if they ae turn commands;

            // if the commands are not the same, we just need to update the curCommand;
            if (same(cur, temp)) {
                compress(cur, temp);
            }

            else {
                compressedCommands.add(cur);
                cur = temp;

                // if this is the last command in the list, we simply add it to the list;
                // if (i == commands.size() - 1)
                // compressedCommands.add(temp);
            }

        }

        compressedCommands.add(cur);
        return compressedCommands;
    }

    public static boolean same(Command c1, Command c2) {

        if (c1 instanceof StraightCommand com1 && c2 instanceof StraightCommand com2) {
            return com1.direction == com2.direction && com1.dist != 0 && com2.dist != 0;
        }

        if (c1 instanceof TurnCommand com1 && c2 instanceof TurnCommand com2) {
            return com1.direction == com2.direction && com1.turn == com2.turn;
        }

        return false;
    }

    public static void compress(Command c1, Command c2) {

        if (c1 instanceof StraightCommand com1 && c2 instanceof StraightCommand com2) {
            // we need to sum the distances if both of them are facing the same direction;
            com1.dist = com1.dist + com2.dist;
        }

        if (c1 instanceof TurnCommand com1 && c2 instanceof TurnCommand com2) {
            com1.turnAngle = com1.turnAngle + com2.turnAngle;
        }
    }
}
