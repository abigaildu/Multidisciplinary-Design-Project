package commands;

import config.RobotConfig.Move;

public class TurnCommand extends Command {
    
    Move direction;
    Move turn;
    double radius;
    double turnAngle;

    public TurnCommand(Move direction, Move turn, double radius, double turnAngle) {

        this.direction = direction;
        this.turn = turn;
        this.radius = radius;
        this.turnAngle = turnAngle;
    }

    public String convertToMessage() {
        // String d = direction == Move.FORWARD ? "F" : "B";
        // String t = turn == Move.TURN_RIGHT ? "R" : "L";

        String d = direction == Move.FORWARD ? 
            (turn == Move.TURN_LEFT ? "L" : "R") : (turn == Move.TURN_LEFT ? "Q" : "E");
            
        String turnString = "" + (int) (turnAngle / 10);

        if(turnString.length() == 1)
            turnString = "00" + turnString;

        else if(turnString.length() == 2)
            turnString = "0" + turnString;


        return d+ turnString;
    }

    @Override
    public String toString() {
        return convertToMessage();
    }
}
