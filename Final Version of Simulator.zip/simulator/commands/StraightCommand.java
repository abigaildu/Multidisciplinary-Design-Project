package commands;

import config.RobotConfig.Move;
import map.Position;

public class StraightCommand extends Command {

    // straight distance to travel;
    // this can either be forward or backward;

    double dist;
    Move direction;

    public StraightCommand(Move direction, double dist) {
        this.dist = Math.round((dist * 10));
        this.direction = direction;
    }

    public String convertToMessage() {
        String d = direction == Move.FORWARD ? "F" : "B";

        String distString = "" + (int) dist;

        // System.out.println(distString);

        if (distString.length() == 1) {
            distString = "00" + distString;
        }

        if (distString.length() == 2) {
            distString = "0" + distString;
        }

        if ((distString).equals("000"))
            return "PPPP"; // PPPP is our photo taking command

        return d + distString;
    }

    @Override
    public String toString() {
        return convertToMessage();
    }

}
