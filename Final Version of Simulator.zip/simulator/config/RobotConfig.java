package config;

public class RobotConfig {

    public static final int SPEED = 10;
    public static final Direction START_DIRECTION = Direction.NORTH;
    
    public enum Direction {
        NORTH, EAST, SOUTH, WEST;

        public static Direction getNextClk(Direction d) {

            return values()[(d.ordinal() + 1) % 4];
        }

        public static Direction getNextAntiClk(Direction d) {

            int newOrdinal = d.ordinal() - 1;
            if(newOrdinal < 0)
                newOrdinal += 4;

            return values()[newOrdinal];
        }

        public static boolean isNextClk(Direction dir1, Direction dir2) {

            return dir2 == getNextClk(dir1);
        }

        public static boolean isNextAntiClk(Direction dir1, Direction dir2) {

            return dir2 == getNextAntiClk(dir1);
        }

        public static double getAngle(Direction d) {

            return switch(d) {
                case NORTH -> Math.PI / 2;
                case EAST -> 0;
                case WEST -> Math.PI;
                case SOUTH -> - Math.PI / 2;
            };
        }
    }

    public enum Move {
        FORWARD, TURN_RIGHT, TURN_LEFT, BACKWARD, STRAIGHTEN_WHEELS;
    }

    public static void main(String[] args) {

        System.out.println(Direction.getNextAntiClk(Direction.WEST));
    }
}
