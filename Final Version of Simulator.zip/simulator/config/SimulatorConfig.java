package config;

import java.awt.Toolkit;
import java.awt.Image;


public class SimulatorConfig {

    public static final String TITLE = "Simulator";
    public static final int FRAME_WIDTH = MapConfig.NUM_COLS * (MapConfig.CELL_SIZE + MapConfig.CELL_PADDING) + 300;
    public static final int FRAME_HEIGHT = MapConfig.NUM_ROWS * (MapConfig.CELL_SIZE + MapConfig.CELL_PADDING) + 300;


    public static final String IMAGE1 = ".\\images\\car.png";
    public static final String IMAGE2 = ".\\images\\obstacle.png";
    public static final Image ROBOT_IMAGE = Toolkit.getDefaultToolkit().getImage(IMAGE1);
    public static final Image OBSTACLE_IMAGE = Toolkit.getDefaultToolkit().getImage(IMAGE2);
}
