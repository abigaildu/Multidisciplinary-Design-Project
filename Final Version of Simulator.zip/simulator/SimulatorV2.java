
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;

import config.MapConfig;
import config.SimulatorConfig;
import map.Cell;
import map.MapV2;
import robot.SimulatorRobot;
import map.SimulatorMap;

import javax.swing.JButton;

public class SimulatorV2 extends JPanel {

    MapV2 map;
    // SimulatorRobot robot;
    Cell[][] arena;

    // this is toggled on and of
    boolean add = true;

    public SimulatorV2() {

        map = new MapV2();
        arena = map.getArena();
        // robot = new SimulatorRobot(new int[] {MapConfig.START_ROW,
        // MapConfig.START_COL});

        this.add(map);
        // map.add(robot);
    }

    @Override
    protected void paintComponent(Graphics g) {

    }

    public void run() {
        JFrame frame = new JFrame(SimulatorConfig.TITLE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(SimulatorConfig.FRAME_WIDTH, SimulatorConfig.FRAME_HEIGHT);
        frame.add(this);
        frame.setVisible(true);

        JPanel options = new JPanel();
        options.setLayout(new BoxLayout(options, BoxLayout.Y_AXIS));
        options.setMaximumSize(new Dimension(3, 3));

        JPanel obstacleOptions = new JPanel();
        JButton addObstacleBtn = new JButton("Add Obstacle");

        addObstacleBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                map.addObstacle = true;
            }
        });

        JButton removeObstacleBtn = new JButton("Remove Obstacle");

        removeObstacleBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                map.addObstacle = false;
            }
        });

        obstacleOptions.add(addObstacleBtn);
        obstacleOptions.add(removeObstacleBtn);

        JPanel algoOptions = new JPanel();
        JButton findPathBtn = new JButton("Find fastest path");
        JButton travelBtn = new JButton("Travel");

        findPathBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                map.findPath();
            }
        });

        travelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                map.animateRobot();
            }
        });

        algoOptions.add(findPathBtn);
        algoOptions.add(travelBtn);

        JPanel resetOptions = new JPanel();
        JButton resetBtn1 = new JButton("Reset Everything");

        resetBtn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                map.reset();
            }
        });

        resetOptions.add(resetBtn1);

        options.add(obstacleOptions);
        options.add(algoOptions);
        options.add(resetOptions);

        frame.setLayout(new BorderLayout());
        frame.add(map, BorderLayout.CENTER);
        frame.add(options, BorderLayout.EAST);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SimulatorV2 sim = new SimulatorV2();
        sim.run();
    }
}