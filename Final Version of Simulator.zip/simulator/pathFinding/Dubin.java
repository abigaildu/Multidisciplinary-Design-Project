package pathFinding;

import config.RobotConfig.Direction;
import config.RobotConfig.Move;
import map.Position;

import java.util.List;
import java.util.ArrayList;

public class Dubin {

    double r;
    public static final double TURN_ANGLE = Math.PI / 2;
    int numPoints = 5;

    public static final double TURN_RADIUS = 22;
    public static final int TURN_COST = (int) Math.round(((TURN_RADIUS / 10) * TURN_ANGLE));

    public Dubin() {

        r = TURN_RADIUS / 10;
    }

    Position calcCenterOfTurn(Position initPos, Move turn) {

        double xCenter;
        double yCenter;

        double x = initPos.getX();
        double y = initPos.getY();
        double theta = initPos.getAngle();

        // this is a counter clockwise turn
        // the center of the turn is to the left of the robot by a distance of
        if (turn == Move.TURN_LEFT) {
            xCenter = x - r * Math.sin(theta);
            yCenter = y + r * Math.cos(theta);
        }

        // this is a right turn
        // it is clockwise
        // the center of the circle is to the right of the robot by a distance of r
        else {
            xCenter = x + r * Math.sin(theta);
            yCenter = y - r * Math.cos(theta);
        }

        return new Position(xCenter, yCenter);
    }

    public Position calcNewPosition(Position initPos, Move turn) {

        Position centerOfTurn = calcCenterOfTurn(initPos, turn);
        double xCenter = centerOfTurn.getX();
        double yCenter = centerOfTurn.getY();

        // now we calculate the angle after the turn;
        Direction curDir = initPos.getDir();
        Direction newDir;

        // this is a antinclockwise turn
        if (turn == Move.TURN_LEFT)
            newDir = Direction.getNextAntiClk(curDir);

        // we turn right
        // this is a clockwise turn
        else
            newDir = Direction.getNextClk(curDir);

        int direction = 1;
        if (turn == Move.TURN_LEFT)
            direction = 1;

        else
            direction = -1;

        double angleRelativeToCircle = turn == Move.TURN_RIGHT ? Direction.getAngle(Direction.getNextAntiClk(curDir))
                : Direction.getAngle(Direction.getNextClk(curDir));

        double newX = xCenter + r * Math.cos(angleRelativeToCircle + direction * TURN_ANGLE);
        double newY = yCenter + r * Math.sin(angleRelativeToCircle + direction * TURN_ANGLE);

        System.out.println(centerOfTurn);

        System.out.println(interpolatePointOnTurn(initPos, centerOfTurn, Move.FORWARD, turn));

        return new Position(newX, newY, newDir);
    }

    public List<Position> interpolatePointOnTurn(Position initPos, Position centerOfTurn, Move straight, Move turn) {

        List<Position> points = new ArrayList<>();

        double theta = initPos.getAngle();
        Direction curDir = initPos.getDir();

        double cx = centerOfTurn.getX();
        double cy = centerOfTurn.getY();

        int direction = 1;
        // if(turn == Move.TURN_LEFT)
        // direction = 1;
        // else
        // direction = -1;

        if ((straight == Move.FORWARD && turn == Move.TURN_LEFT) ||
                (straight == Move.BACKWARD && turn == Move.TURN_RIGHT))
            direction = 1;

        else
            direction = -1;

        double angleRelativeToCircle = turn == Move.TURN_RIGHT ? Direction.getAngle(Direction.getNextAntiClk(curDir))
                : Direction.getAngle(Direction.getNextClk(curDir));

        double alpha = TURN_ANGLE * direction;

        double angleIncrement = alpha / numPoints;

        // now we interpolate the points along the circular arc
        for (int i = 0; i <= numPoints; i++) {

            double curTheta = theta + (direction * i * angleIncrement);
            double curAlpha = (i * angleIncrement);

            // calculate the interpolated position
            double nx = cx + r * Math.cos(angleRelativeToCircle + curAlpha);
            double ny = cy + r * Math.sin(angleRelativeToCircle + curAlpha);

            points.add(new Position(nx, ny, curTheta));
        }

        // the last element of the points is the finalPos
        // we need to set its direction;
        Direction newDir;

        if ((straight == Move.FORWARD && turn == Move.TURN_RIGHT) ||
                (straight == Move.BACKWARD && turn == Move.TURN_LEFT))
            newDir = Direction.getNextClk(curDir);

        else
            newDir = Direction.getNextAntiClk(curDir);

        int[] offset = switch (newDir) {
            case NORTH -> straight == Move.FORWARD ? new int[] { 0, 1 } : new int[] { 0, 0 };
            case WEST -> straight == Move.FORWARD ? new int[] { -1, 0 } : new int[] { 0, 0 };
            case EAST -> straight == Move.FORWARD ? new int[] { 1, 0 } : new int[] { 0, 0 };
            case SOUTH -> straight == Move.FORWARD ? new int[] { 0, -1 } : new int[] { 0, 0 };
        };

        Position lastPos = points.get(points.size() - 1);
        double lastX = lastPos.getX() + offset[0];
        double lastY = lastPos.getY() + offset[1];

        points.add(new Position(lastX, lastY, newDir));

        // points.get(points.size() - 1).setDir(newDir);
        return points;
    }

    public List<Position> getPathToNeighbour(Position initPos, Move straight, Move turn) {

        Position centerOfTurn = calcCenterOfTurn(initPos, turn);
        return interpolatePointOnTurn(initPos, centerOfTurn, straight, turn);
    }
}
