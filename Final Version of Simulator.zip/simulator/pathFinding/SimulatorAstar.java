package pathFinding;

import config.RobotConfig.Direction;
import config.RobotConfig.Move;
import map.Cell;
import map.Position;
import robot.SimulatorRobot;
import map.SimulatorMap;

import java.util.Set;

import commands.Command;

import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Queue;
import java.util.PriorityQueue;
import java.util.Collections;

public class SimulatorAstar {

    Queue<Position> frontier = new PriorityQueue<>(new Comparator<Position>() {

        @Override
        public int compare(Position pos1, Position pos2) {

            return Integer.compare(
                    cost.get(pos1.getEqualString()),
                    cost.get(pos2.getEqualString()));
        }

    });

    HashMap<String, Position> parent = new HashMap<>();
    Set<String> visited = new HashSet<>();

    HashMap<String, Integer> gCost = new HashMap<>();
    HashMap<String, Integer> cost = new HashMap<>();

    Dubin dubin = new Dubin();
    SimulatorPathFinder pathFinder;

    SimulatorMap map;
    Cell[][] arena;
    SimulatorRobot robot;

    double minCost = Double.MAX_VALUE;

    // lets add a timer feature to our algorithm
    final long TIMEOUT = 5000;

    // lets also add a strict mode to our robot;
    boolean strictMode = true;

    final int RELAXED_PENALTY = 20;

    Position curPos;

    public SimulatorAstar(SimulatorMap map, SimulatorRobot robot) {

        this.map = map;
        this.arena = map.getArena();
        this.robot = robot;

        pathFinder = new SimulatorPathFinder(map, robot);
        // System.out.println(dubin.getPathToNeighbour(new Position(1, 1,
        // Direction.NORTH), Move.TURN_LEFT));

    }

    public void reset() {
        frontier.clear();
        parent.clear();
        gCost.clear();
        cost.clear();
        visited.clear();
    }

    public boolean validNeighbour(Position neigbour) {

        int nx = neigbour.getIntX();
        int ny = neigbour.getIntY();

        int[][] occupiedCoordsOffset = robot.getOccupyingCoordsOffset();
        // we need to make sure that the robot does not get too close to any obstacle
        boolean mayCollide = false;

        if (strictMode) {
            for (int[] coord : occupiedCoordsOffset) {
                int tx = curPos.getIntX() + coord[0];
                int ty = curPos.getIntY() + coord[1];

                if (!map.areValidCoordinates(tx, ty) || arena[tx][ty].isVirtualWall()) {
                    mayCollide = true;
                    break;
                }
            }
        }

        return map.areValidCoordinates(nx, ny) &&
                !arena[nx][ny].hasObstacle() &&
                !arena[nx][ny].isVirtualWall() &&
                !mayCollide;
    }

    public boolean validNeighbourPath(List<Position> path) {

        for (Position point : path) {
            if (!validNeighbour(point))
                return false;
        }

        return true;
    }

    // this function helps us to get a neighbours of the current position
    // but we only want to return valid neigbours;
    public List<Position> getNeighbours(Position curPos) {

        List<Position> neighbours = new ArrayList<>();

        int x = curPos.getIntX();
        int y = curPos.getIntY();
        Direction curDir = curPos.getDir();

        // the forward coordinate
        double fwdx = x;
        double fwdy = y;

        double bwdx = x;
        double bwdy = y;

        switch (curDir) {
            case NORTH:
                fwdy += 1;
                bwdy -= 1;
                break;

            case SOUTH:
                fwdy -= 1;
                bwdy += 1;
                break;

            case EAST:
                fwdx += 1;
                bwdx -= 1;
                break;

            case WEST:
                fwdx -= 1;
                bwdx += 1;
                break;

            default:
                break;
        }

        // for now our robot move forward and backward;
        List<Position> pathToLeftNeighbourFwd = dubin.getPathToNeighbour(curPos, Move.FORWARD, Move.TURN_LEFT);
        List<Position> pathToRightNeighbourFwd = dubin.getPathToNeighbour(curPos, Move.FORWARD, Move.TURN_RIGHT);

        List<Position> pathToLeftNeighbourBwd = dubin.getPathToNeighbour(curPos, Move.BACKWARD, Move.TURN_LEFT);
        List<Position> pathToRightNeighbourBwd = dubin.getPathToNeighbour(curPos, Move.BACKWARD, Move.TURN_RIGHT);

        Position fwdNeighbour = new Position(fwdx, fwdy, curDir);
        Position leftNeighbourFwd = pathToLeftNeighbourFwd.get(pathToLeftNeighbourFwd.size() - 1);
        Position rightNeighbourFwd = pathToRightNeighbourFwd.get(pathToRightNeighbourFwd.size() - 1);

        // now our robot can also move backward
        Position bwdNeighbour = new Position(bwdx, bwdy, curDir);
        Position leftNeighbourBwd = pathToLeftNeighbourBwd.get(pathToLeftNeighbourBwd.size() - 1);
        Position rightNeighbourBwd = pathToRightNeighbourBwd.get(pathToRightNeighbourBwd.size() - 1);

        // now that we have the neighbours, we need to validate them
        // we need to check for collisions
        // virtual walls
        // obstacles

        if (validNeighbour(fwdNeighbour))
            neighbours.add(fwdNeighbour);

        if (validNeighbourPath(pathToRightNeighbourFwd))
            neighbours.add(rightNeighbourFwd);

        if (validNeighbourPath(pathToLeftNeighbourFwd))
            neighbours.add(leftNeighbourFwd);

        if (validNeighbour(bwdNeighbour))
            neighbours.add(bwdNeighbour);

        if (validNeighbourPath(pathToRightNeighbourBwd))
            neighbours.add(rightNeighbourBwd);

        if (validNeighbourPath(pathToLeftNeighbourBwd))
            neighbours.add(leftNeighbourBwd);

        return neighbours;
    }

    public List<Position> reconstructPath(Position curPos) {

        List<Position> path = new ArrayList<>();

        while (curPos != null) {

            path.add(curPos);
            curPos = parent.get(curPos.getEqualString());
        }

        Collections.reverse(path);

        return path;
    }

    public List<Position> findOptimalPath(Position start, Position goal) {

        reset();

        long startTime = System.currentTimeMillis();

        curPos = start;
        gCost.put(curPos.getEqualString(), 0);
        cost.put(curPos.getEqualString(),
                gCost.get(curPos.getEqualString()) + pathFinder.calcManhatanDistance(curPos, goal));

        // now we add the curPos into the frontier
        frontier.add(curPos);

        while (!frontier.isEmpty()) {

            curPos = frontier.poll();

            long currentTime = System.currentTimeMillis();

            if (currentTime - startTime > TIMEOUT) {
                return reconstructPath(curPos);
            }

            // mark this curPos as visited;
            visited.add(curPos.getEqualString());

            // if the curPos is the goal, well done
            // we have found a path
            if (curPos.equals(goal)) {
                System.out.println("Found a path");

                // return the reconstructed path;
                return reconstructPath(curPos);
            }

            // we need to get the neigbours of the curPos;
            // these neighbours have been already been validated
            List<Position> neighbours = getNeighbours(curPos);

            // the algorithm needs to be relaxed if we were not able to find any neihbours;
            if (neighbours.isEmpty()) {
                strictMode = false;
                neighbours = getNeighbours(curPos);
            }

            for (Position neighbour : neighbours) {

                // we need to skip over the neighbours that have already been visited
                if (visited.contains(neighbour.getEqualString())) {
                    continue;
                }

                // now we need to calculate the cost of each neighbour
                int tempGCost = gCost.get(curPos.getEqualString()) + 1;

                // if the strict mode was false, we add another penalty;
                if (!strictMode) {
                    tempGCost += RELAXED_PENALTY;
                }

                // we add a TURN PENALTY if there has been a turn
                if (neighbour.getDir() != curPos.getDir())
                    tempGCost += Dubin.TURN_COST;

                int tempCost = tempGCost + pathFinder.calcManhatanDistance(neighbour, goal);

                // and we update the neighbours stats if the cost is lower
                if (!gCost.containsKey(neighbour.getEqualString()) || tempCost < cost.get(neighbour.getEqualString())) {

                    parent.put(neighbour.getEqualString(), curPos);
                    gCost.put(neighbour.getEqualString(), tempGCost);
                    cost.put(neighbour.getEqualString(), tempCost);

                    if (!frontier.contains(neighbour)) {
                        frontier.add(neighbour);
                    }
                }
            }

            // we set strict mode to true again;
            strictMode = true;
        }

        // if we are here, it means we have found no path
        return null;
    }

    public List<Position> run() {

        List<Position> path = new ArrayList<>();
        List<Command> commands = new ArrayList<>();

        // first we get the simple hamiltonian path
        // using the path finder
        List<Position> hamiltonianPath = pathFinder.computeSimpleHamiltonianPath();

        System.out.printf("The order is: %n%s%n", hamiltonianPath);

        Position curPos = map.getStartPosition();
        for (int i = 1; i < hamiltonianPath.size(); i++) {

            int targetIndex = i;

            var partialPath = findOptimalPath(curPos, hamiltonianPath.get(i));
            path.addAll(partialPath);

            curPos = partialPath.get(partialPath.size() - 1);

            // if for any reason, the algo couldnt find a paht, we reset everything and find
            // a path from
            // its curPos to the target;
            // if
            // (!curPos.getEqualString().equals(hamiltonianPath.get(targetIndex).getEqualString()))
            // i -= 1;

            // curPos = hamiltonianPath.get(i);

            System.out.println(partialPath);
            System.out.print("\nCommands: ");
            System.out.println(Command.convertToCommand(partialPath));

            commands.addAll(Command.convertToCommand(partialPath));

            System.out.println("-".repeat(150));
        }

        return path;
        // System.out.println("Total Cost: " +
        // cost.get(map.getEndPosition().getEqualString()));

        // System.out.println(path);
        // System.out.println(findOptimalPath(new Position(2, 7, Direction.SOUTH),
        // map.getEndPosition()));

    }
}
