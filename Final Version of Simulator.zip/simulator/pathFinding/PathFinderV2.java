package pathFinding;

import map.Cell;
import map.MapV2;
import map.Position;
import map.mapElements.SimulatorObstacle;
import robot.RobotV2;
import robot.SimulatorRobot;
import map.SimulatorMap;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class PathFinderV2 {

    MapV2 map;
    RobotV2 robot;
    Cell[][] arena;

    List<List<Position>> simpleHamiltonian = new ArrayList<>();
    List<Position> bestVisitingOrder;

    public PathFinderV2(MapV2 map, RobotV2 robot) {

        this.map = map;
        this.robot = robot;
        arena = map.getArena();
    }

    public class Permutation {

        List<List<Position>> res = new ArrayList<>();
        List<Position> sol = new ArrayList<>();

        public List<List<Position>> getPermutations() {

            // we clear them just incase we want to reuse the function
            res.clear();
            sol.clear();

            sol.add(map.getStartPosition());

            backtrack();

            return res;
        }

        public void backtrack() {

            if (sol.size() - 1 == map.getObstacles().size()) {

                res.add(new ArrayList<>(sol));
                // res.get(res.size() - 1).add(map.getEndPosition());
                return;
            }

            for (SimulatorObstacle obstacle : map.getObstacles()) {

                Position targetPos = robot.computeScanningPosition(obstacle);

                // we only add the targetCell to the permutation if it hasnt been added before
                if (sol.contains(targetPos)) {
                    continue;
                }
                ;

                sol.add(targetPos);
                backtrack();
                sol.remove(sol.size() - 1);
            }
        }
    }

    public List<Position> computeSimpleHamiltonianPath() {

        Permutation permutation = new Permutation();
        simpleHamiltonian = permutation.getPermutations();

        simpleHamiltonian.sort(new Comparator<List<Position>>() {

            @Override
            public int compare(List<Position> list1, List<Position> list2) {

                return Integer.compare(
                        calcManhatanDistance(list1),
                        calcManhatanDistance(list2));
            }
        });

        // System.out.println(simpleHamiltonian.size());
        // System.out.println("These are the possible path");
        // for(var path : simpleHamiltonian) {
        // for(var pos : path) {
        // System.out.print(pos + " -> ");
        // }
        // System.out.println(calcManhatanDistance(path));
        // }

        bestVisitingOrder = simpleHamiltonian.get(0);

        // System.out.println(bestVisitingOrder);

        return bestVisitingOrder;
    }

    public int calcManhatanDistance(Position pos1, Position pos2) {

        int xDist = Math.abs(pos1.getIntX() - pos2.getIntX());
        int yDist = Math.abs(pos1.getIntY() - pos2.getIntY());

        return xDist + yDist;
    }

    public int calcManhatanDistance(List<Position> positions) {

        int dist = 0;

        for (int i = 0; i < positions.size() - 1; i++) {

            dist += calcManhatanDistance(positions.get(i), positions.get(i + 1));
        }

        return dist;
    }
}
